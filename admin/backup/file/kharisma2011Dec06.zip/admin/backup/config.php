<?php
    // Settings
    $DBhost = 'localhost';
    $DBuser = 'root';
    $DBpass = '';
    $DBName = 'kharisma_db';
    $table = '*';
?>