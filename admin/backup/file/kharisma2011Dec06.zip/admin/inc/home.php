<h2>Selamat Datang</h2>
Selamat datang <b><?php echo $_SESSION['nama_admin']; ?> </b>di halaman administrator website <b>E-Commerce Kharisma Musik Indramayu</b>.
<br>
Silahkan klik menu pilihan yang berada di sebelah kiri untuk mengelola content website. 
<br />
