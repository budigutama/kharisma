 
   	<div class="center_title_bar">Batal</div>
    
    	<div class="prod_box_big">
      
            <div class="center_prod_box_big">
                Pembayaran dibatalkan.
          </div>                             
</div>
                                 
     
    
   
  