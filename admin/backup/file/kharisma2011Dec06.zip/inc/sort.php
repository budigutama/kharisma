   
  <div class="dropdown">
    <a href="#" class="button"><span class="icon icon19"></span><span class="label1">Urut Berdasarkan</span><span class="toggle"></span></a>
    <div class="dropdown-slider">
      <a href="?urutkan=produk_terbaru" class="ddm"><span class="icon icon107"></span><span class="label1">Produk Terbaru</span></a>
      <a href="?urutkan=produk_terlaris" class="ddm"><span class="icon icon101"></span><span class="label1">Produk Terlaris</span></a>
      <a href="?urutkan=produk_diskon" class="ddm"><span class="icon icon51"></span><span class="label1">Produk Diskon</span></a>
    </div> <!-- /.dropdown-slider -->
  </div> <!-- /.dropdown -->

