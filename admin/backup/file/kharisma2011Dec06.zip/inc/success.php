 
   	<div class="center_title_bar">Pembayaran Sukses</div>
    
    	<div class="prod_box_big">
      
            <div class="center_prod_box_big">
                Pembayaran sukses. Terimakasih telah berbelanja di toko kami.
          </div>                             
</div>
                                 
     
    
   
  