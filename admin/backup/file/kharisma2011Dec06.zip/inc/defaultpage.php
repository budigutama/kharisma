<div class="center_title_bar">Error Loading Page</div>
	<div class="prod_box_big">
		<div class="center_prod_box_big">
        Maaf, Halaman yang Anda Minta Tidak Ada.
        </div>
    </div>