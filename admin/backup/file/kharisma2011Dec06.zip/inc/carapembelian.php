<div class="center_title_bar">Cara Pembelian</div>
<div class="prod_box_big">
	<div class="center_prod_box_big">
    
    	<H3 align="left">Cara Pembelian</H3>
 
        	<p align="left">1. Klik pada tombol Beli pada produk yang ingin Anda pesan</p>
            <p align="left"> 2. Produk yang Anda pesan akan masuk ke dalam Keranjang Belanja. Anda dapat melakukan perubahan jumlah produk yang diinginkan dengan mengganti angka di kolom Jumlah, kemudian klik tombol Update. Sedangkan untuk menghapus sebuah produk dari Keranjang Belanja, klik tombol Kali yang berada di kolom paling kanan.            </p>
            <p align="left">3. Jika sudah selesai, klik tombol Selesai Belanja, maka akan tampil form untuk pengisian data kustomer/pembeli.</p>
            <p align="left"> 4. Setelah data pembeli selesai diisikan, klik tombol Proses, maka akan tampil data pembeli beserta produk yang dipesannya (jika diperlukan catat nomor ordersnya). Dan juga ada total pembayaran serta nomor rekening pembayaran.</p>
            <p align="left"> 5. Apabila telah melakukan pembayaran, maka produk/barang akan segera kami kirimkan. </p>
            
	</div>
</div>