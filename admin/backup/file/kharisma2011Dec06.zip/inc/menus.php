
<div class="buttons"> 
  <a href="?page=home" class="button" title="Beranda">
  <span class="icon icon108"></span><span class="label1">Beranda</span>
  </a>
  <a href="?page=kontak" class="button">
  <span class="icon icon125"></span><span class="label1">Hubungi Kami</span>
  </a>
  <a href="?page=carapembayaran" class="button">
  <span class="icon icon130"></span><span class="label1">Cara pembayaran</span>
  </a>
  <a href="?page=carapembelian" class="button">
  <span class="icon icon169"></span><span class="label1">Cara Pembelian</span>
  </a>
	   <?php include "login.php"; ?>
</div> 
