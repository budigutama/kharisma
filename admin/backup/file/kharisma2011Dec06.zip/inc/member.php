<div class="border_box">
  <p>Lihat histori</p>
  <p>Acount setting</p>
  <p>Retur</p>
  <p>Log out</p>
</div>  